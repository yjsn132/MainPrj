package com.tech.mainPrj.dto;

public class LikeOrDislike {
	private int mnum;
	private int rnumber;
	private int lod;
	private int declaration;
	
	
	public int getMnum() {
		return mnum;
	}
	public void setMnum(int mnum) {
		this.mnum = mnum;
	}
	public int getRnumber() {
		return rnumber;
	}
	public void setRnumber(int rnumber) {
		this.rnumber = rnumber;
	}
	public int getLod() {
		return lod;
	}
	public void setLod(int lod) {
		this.lod = lod;
	}
	public int getDeclaration() {
		return declaration;
	}
	public void setDeclaration(int declaration) {
		this.declaration = declaration;
	}
	
}
