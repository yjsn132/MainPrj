package com.tech.mainPrj.dto;

public class ProductIngredient {
	private int pnumber;
	private String ingredient;
	private String ilevel;
	private String ipurpose;
	
	
	public int getPnumber() {
		return pnumber;
	}
	public void setPnumber(int pnumber) {
		this.pnumber = pnumber;
	}
	public String getIngredient() {
		return ingredient;
	}
	public void setIngredient(String ingredient) {
		this.ingredient = ingredient;
	}
	public String getIlevel() {
		return ilevel;
	}
	public void setIlevel(String ilevel) {
		this.ilevel = ilevel;
	}
	public String getIpurpose() {
		return ipurpose;
	}
	public void setIpurpose(String ipurpose) {
		this.ipurpose = ipurpose;
	}
	
}
